package com.mobileprivacy.analyzer

import android.util.Log

object PacketParser {
    fun parse(packet: ByteArray, length: Int) {
        val data = String(packet, 0, length)
        if (data.contains("facebook") || data.contains("googleads")) {
            Log.d("PrivacyAnalyzer", "Tracker Detected: $data")
        }
    }
}