package com.mobileprivacy.analyzer

import android.net.VpnService
import android.os.ParcelFileDescriptor
import java.io.FileInputStream
import java.io.FileOutputStream
import kotlin.concurrent.thread

class PrivacyVPNService : VpnService() {

    private var vpnInterface: ParcelFileDescriptor? = null

    override fun onStartCommand(intent: android.content.Intent?, flags: Int, startId: Int): Int {
        val builder = Builder()
        builder.setSession("MobilePrivacyAnalyzer")
            .addAddress("10.0.0.2", 32)
            .addRoute("0.0.0.0", 0)

        vpnInterface = builder.establish()

        thread { captureTraffic() }
        return START_STICKY
    }

    private fun captureTraffic() {
        val input = FileInputStream(vpnInterface!!.fileDescriptor)
        val output = FileOutputStream(vpnInterface!!.fileDescriptor)
        val packet = ByteArray(32767)

        while (true) {
            val length = input.read(packet)
            if (length > 0) {
                PacketParser.parse(packet, length)
                output.write(packet, 0, length)
            }
        }
    }
}