package com.mobileprivacy.analyzer

object DomainClassifier {

    private val trackers = listOf(
        "googleads", "doubleclick", "facebook", "analytics", "adservice"
    )

    fun isTracker(domain: String): Boolean {
        return trackers.any { domain.contains(it) }
    }
}