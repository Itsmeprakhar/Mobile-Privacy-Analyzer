# Mobile Privacy Analyzer

Mobile Privacy Analyzer is an academic Android application that monitors mobile network traffic using VPN-based packet inspection to detect advertisement and tracking domains.

## Features
- Local VPN traffic analyzer
- Tracker & advertisement domain detection
- Privacy risk monitoring
- Academic research use

## Tech Stack
- Kotlin
- Android VPNService API
- Packet Inspection
- Domain Classification

## Disclaimer
This project is for educational and research purposes only.